#!/usr/bin/env python3
"""main.py v2.1.0 – Verbrannte Zone Backend
Neu: Provinz-Besitz, Ressourcen-Lager pro Provinz, Handelskarren-Transport"""
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional, List
import sqlite3, json, os, math

DB_PATH = "verbrannte_zone.db"
ROAD_COSTS     = {1:50,  2:100, 3:200, 4:400}
CROSSING_COSTS = {1:100, 2:200, 3:400, 4:800}
BUILDING_COSTS = {"building_mine":500,"building_factory":1000,"building_bunker":2000,
                  "building_powerplant":1500,"building_refinery":1200}
HANDELSKARREN_ID       = 1   # Ressource-ID
HANDELSKARREN_KAPAZITÄT = 50  # Platz pro Karren

for _d in ["css","js","terrains"]:
    os.makedirs(_d, exist_ok=True)

# ─── DB ──────────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = get_db(); cur = conn.cursor()

    # Stamm-Tabellen
    cur.execute("""CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL DEFAULT 'Spieler',
        iron INTEGER DEFAULT 1000, steel INTEGER DEFAULT 500, fuel INTEGER DEFAULT 200,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS roads (
        id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER NOT NULL,
        world_x INTEGER NOT NULL, world_y INTEGER NOT NULL,
        grid_x INTEGER NOT NULL, grid_y INTEGER NOT NULL,
        road_type TEXT NOT NULL DEFAULT 'road', level INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (player_id) REFERENCES players(id))""")

    cur.execute("""CREATE TABLE IF NOT EXISTS buildings (
        id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER NOT NULL,
        world_x INTEGER NOT NULL, world_y INTEGER NOT NULL,
        building_x INTEGER NOT NULL, building_y INTEGER NOT NULL,
        building_type TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(player_id,world_x,world_y,building_x,building_y),
        FOREIGN KEY (player_id) REFERENCES players(id))""")

    cur.execute("""CREATE TABLE IF NOT EXISTS gebaeude_typen (
        id INTEGER PRIMARY KEY, name TEXT NOT NULL,
        symbol_emoji TEXT DEFAULT '', symbol_url TEXT DEFAULT '', bild_url TEXT DEFAULT '',
        kategorie TEXT DEFAULT '', bautyp TEXT DEFAULT 'Land',
        baubar INTEGER DEFAULT 1, ausbaubar INTEGER DEFAULT 0,
        unique_gebaeude INTEGER DEFAULT 0, nur_kueste INTEGER DEFAULT 0, ist_feld INTEGER DEFAULT 0,
        tech_level INTEGER DEFAULT 0, baukosten_mips INTEGER DEFAULT 0,
        ausbaukosten_mips INTEGER DEFAULT 0, energiebedarf INTEGER DEFAULT 0,
        arbeiter INTEGER DEFAULT 0, zusatzarbeiter_pro_stufe INTEGER DEFAULT 0,
        wohnraum INTEGER DEFAULT 0, zusatzwohnraum_pro_stufe INTEGER DEFAULT 0,
        lagerkapazitaet INTEGER DEFAULT 0, beschreibung TEXT DEFAULT '',
        rohstoffbedarf_bau TEXT DEFAULT '[]', rohstoffgrundbedarf_ausbau TEXT DEFAULT '[]',
        rohstoffverbrauch TEXT DEFAULT '[]', produktion TEXT DEFAULT '[]',
        terrain_effektivitaet TEXT DEFAULT '{}', vorkommen_effektivitaet TEXT DEFAULT '{}',
        spezial_eigenschaften TEXT DEFAULT '{}', schlachtfeld TEXT DEFAULT '{}',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS provinz_feldtypen (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, beschreibung TEXT DEFAULT '',
        groesse_px INTEGER DEFAULT 30, ist_baubar INTEGER DEFAULT 1,
        bautypen TEXT DEFAULT '[]', farbe_leer TEXT DEFAULT '#444',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS ressourcen (
        id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, typ TEXT NOT NULL,
        wert INTEGER DEFAULT 0, verbrauch INTEGER DEFAULT 0, platzbedarf INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")

    cur.execute("""CREATE TABLE IF NOT EXISTS vorkommen (
        id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE,
        typ TEXT NOT NULL, tech INTEGER DEFAULT 0, suchkosten INTEGER DEFAULT 0,
        beschreibung TEXT DEFAULT '', findwahrscheinlichkeit TEXT DEFAULT '{}',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")

    # NEU: Provinz-Besitz
    cur.execute("""CREATE TABLE IF NOT EXISTS provinzen (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        world_x INTEGER NOT NULL,
        world_y INTEGER NOT NULL,
        name TEXT DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(world_x, world_y),
        FOREIGN KEY (player_id) REFERENCES players(id))""")

    # NEU: Ressourcen-Lager pro Provinz
    cur.execute("""CREATE TABLE IF NOT EXISTS provinz_lager (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        provinz_id INTEGER NOT NULL,
        ressource_id INTEGER NOT NULL,
        menge INTEGER NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(provinz_id, ressource_id),
        FOREIGN KEY (provinz_id) REFERENCES provinzen(id),
        FOREIGN KEY (ressource_id) REFERENCES ressourcen(id))""")

    # NEU: Handelskarren-Transport-Log
    cur.execute("""CREATE TABLE IF NOT EXISTS handelskarren_transport (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        von_provinz_id INTEGER NOT NULL,
        nach_provinz_id INTEGER NOT NULL,
        ressource_id INTEGER NOT NULL,
        menge INTEGER NOT NULL,
        karren_benoetigt INTEGER NOT NULL DEFAULT 1,
        status TEXT NOT NULL DEFAULT 'angekommen',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        angekommen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (player_id) REFERENCES players(id),
        FOREIGN KEY (von_provinz_id) REFERENCES provinzen(id),
        FOREIGN KEY (nach_provinz_id) REFERENCES provinzen(id),
        FOREIGN KEY (ressource_id) REFERENCES ressourcen(id))""")

    # Migrationen (gebaeude_typen)
    for col, defn in [
        ("vorkommen_effektivitaet","TEXT DEFAULT '{}'"),
        ("ausbaukosten_mips","INTEGER DEFAULT 0"),
        ("rohstoffgrundbedarf_ausbau","TEXT DEFAULT '[]'"),
        ("zusatzarbeiter_pro_stufe","INTEGER DEFAULT 0"),
        ("zusatzwohnraum_pro_stufe","INTEGER DEFAULT 0"),
    ]:
        try: cur.execute(f"ALTER TABLE gebaeude_typen ADD COLUMN {col} {defn}")
        except: pass

    # Migrationen (vorkommen)
    for col, defn in [
        ("beschreibung","TEXT DEFAULT ''"),
        ("findwahrscheinlichkeit","TEXT DEFAULT '{}'"),
    ]:
        try: cur.execute(f"ALTER TABLE vorkommen ADD COLUMN {col} {defn}")
        except: pass

    # Default-Spieler + Provinz-Feldtypen
    cur.execute("INSERT OR IGNORE INTO players (id,name) VALUES (1,'Spieler 1')")
    for ft in [
        ("gebaeude","Gebäudefeld","Landfeld",30,1,'["Land"]',"#5a7a3a"),
        ("stadt","Stadtfeld","Stadtfeld",30,1,'["Stadt"]',"#6a6a8a"),
        ("stadtausbau","Stadtausbau","Provinzausbau",30,1,'["Stadtausbau"]',"#4a4a7a"),
        ("weg","Wegfeld","Wegfeld",10,1,'["Weg"]',"#8b7355"),
        ("kreuzung","Kreuzungsfeld","Kreuzung",10,1,'["Wegkreuzung"]',"#7a6345"),
        ("vorgabe","Vorgabefeld","Vorgabe",30,0,'["Vorgabe"]',"#3a3a5a"),
    ]:
        cur.execute("INSERT OR IGNORE INTO provinz_feldtypen (id,name,beschreibung,groesse_px,ist_baubar,bautypen,farbe_leer) VALUES (?,?,?,?,?,?,?)",ft)

    conn.commit(); conn.close()

init_db()

# ─── FastAPI ──────────────────────────────────────────────────────────────────
app = FastAPI(title="Verbrannte Zone API", version="2.1.0")

# ─── Helpers ──────────────────────────────────────────────────────────────────
def safe_json(val, default):
    if isinstance(val, str):
        try: return json.loads(val)
        except: return default
    return val if val is not None else default

def get_provinz_or_403(cur, player_id: int, provinz_id: int):
    """Provinz laden und prüfen ob sie dem Spieler gehört."""
    cur.execute("SELECT * FROM provinzen WHERE id=?", (provinz_id,))
    p = cur.fetchone()
    if not p:
        raise HTTPException(404, f"Provinz {provinz_id} nicht gefunden")
    if p["player_id"] != player_id:
        raise HTTPException(403, "Diese Provinz gehört dir nicht")
    return p

def get_lager_menge(cur, provinz_id: int, ressource_id: int) -> int:
    cur.execute("SELECT menge FROM provinz_lager WHERE provinz_id=? AND ressource_id=?",
                (provinz_id, ressource_id))
    row = cur.fetchone()
    return row["menge"] if row else 0

def lager_set(cur, provinz_id: int, ressource_id: int, neue_menge: int):
    if neue_menge < 0:
        raise HTTPException(400, "Menge kann nicht negativ sein")
    if neue_menge == 0:
        cur.execute("DELETE FROM provinz_lager WHERE provinz_id=? AND ressource_id=?",
                    (provinz_id, ressource_id))
    else:
        cur.execute("""INSERT INTO provinz_lager (provinz_id, ressource_id, menge)
                       VALUES (?,?,?)
                       ON CONFLICT(provinz_id, ressource_id)
                       DO UPDATE SET menge=excluded.menge, updated_at=CURRENT_TIMESTAMP""",
                    (provinz_id, ressource_id, neue_menge))

def fmt_provinz(r):
    return {"id":r["id"],"player_id":r["player_id"],
            "world_x":r["world_x"],"world_y":r["world_y"],
            "name":r["name"] or f"Provinz ({r['world_x']},{r['world_y']})",
            "created_at":r["created_at"]}

def fmt_lager_eintrag(r):
    return {"ressource_id":r["ressource_id"],"ressource_name":r["ressource_name"],
            "typ":r["typ"],"wert":r["wert"],"platzbedarf":r["platzbedarf"],
            "menge":r["menge"],"gesamtwert":r["menge"]*r["wert"]}

def fmt_gebaeude(r):
    bautyp=r["bautyp"] or "Land"
    fmap={"Land":"gebaeude","Stadt":"stadt","Stadtausbau":"stadtausbau",
          "Weg":"weg","Wegkreuzung":"kreuzung","Vorgabe":"vorgabe"}
    return {"id":r["id"],"name":r["name"],"symbol_emoji":r["symbol_emoji"],
            "symbol_url":r["symbol_url"],"bild_url":r["bild_url"],
            "kategorie":r["kategorie"],"bautyp":bautyp,
            "provinz_feldtyp":fmap.get(bautyp),"baubar":bool(r["baubar"]),
            "ausbaubar":bool(r["ausbaubar"]),"unique_gebaeude":bool(r["unique_gebaeude"]),
            "nur_kueste":bool(r["nur_kueste"]),"ist_feld":bool(r["ist_feld"]),
            "tech_level":r["tech_level"],"baukosten_mips":r["baukosten_mips"],
            "ausbaukosten_mips":r["ausbaukosten_mips"],"energiebedarf":r["energiebedarf"],
            "arbeiter":r["arbeiter"],"zusatzarbeiter_pro_stufe":r["zusatzarbeiter_pro_stufe"],
            "wohnraum":r["wohnraum"],"zusatzwohnraum_pro_stufe":r["zusatzwohnraum_pro_stufe"],
            "lagerkapazitaet":r["lagerkapazitaet"],"beschreibung":r["beschreibung"],
            "rohstoffbedarf_bau":safe_json(r["rohstoffbedarf_bau"],[]),
            "rohstoffgrundbedarf_ausbau":safe_json(r["rohstoffgrundbedarf_ausbau"],[]),
            "rohstoffverbrauch":safe_json(r["rohstoffverbrauch"],[]),
            "produktion":safe_json(r["produktion"],[]),
            "terrain_effektivitaet":safe_json(r["terrain_effektivitaet"],{}),
            "vorkommen_effektivitaet":safe_json(r["vorkommen_effektivitaet"],{}),
            "spezial_eigenschaften":safe_json(r["spezial_eigenschaften"],{}),
            "schlachtfeld":safe_json(r["schlachtfeld"],{})}

def fmt_ressource(r):
    return {"id":r["id"],"name":r["name"],"typ":r["typ"],
            "wert":r["wert"],"verbrauch":r["verbrauch"],"platzbedarf":r["platzbedarf"]}

def fmt_vorkommen(r):
    return {"id":r["id"],"name":r["name"],"typ":r["typ"],"tech":r["tech"],
            "suchkosten":r["suchkosten"],"beschreibung":r["beschreibung"] or "",
            "findwahrscheinlichkeit":safe_json(r["findwahrscheinlichkeit"],{})}

# ─── Pydantic Models ──────────────────────────────────────────────────────────
class ProvinzCreate(BaseModel):
    world_x: int
    world_y: int
    name: Optional[str] = ""

class LagerUpdate(BaseModel):
    menge: int   # absolute neue Menge

class LagerDelta(BaseModel):
    delta: int   # +/- Änderung

class TransportRequest(BaseModel):
    nach_provinz_id: int
    ressource_id: int
    menge: int

class RoadUpgrade(BaseModel):
    road_type: str; grid_x: int; grid_y: int; new_level: int

class BuildingCreate(BaseModel):
    building_type: str; x: int; y: int

# ─── Endpoints: Frontend ──────────────────────────────────────────────────────
@app.get("/")
async def root():
    return FileResponse("index.html")

# ─── Endpoints: Spieler ───────────────────────────────────────────────────────
@app.get("/player/{player_id}")
async def get_player(player_id: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT * FROM players WHERE id=?", (player_id,))
    p = cur.fetchone(); conn.close()
    if not p: raise HTTPException(404, "Spieler nicht gefunden")
    return {"id":p["id"],"name":p["name"],"iron":p["iron"],"steel":p["steel"],"fuel":p["fuel"]}

@app.post("/player/{player_id}/resources/produce")
async def produce_resources(player_id: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT id FROM players WHERE id=?", (player_id,))
    if not cur.fetchone(): conn.close(); raise HTTPException(404, "Spieler nicht gefunden")
    
    # 1. Ressourcen Map laden (name -> id, id -> platzbedarf)
    cur.execute("SELECT id, name, platzbedarf FROM ressourcen")
    res_rows = cur.fetchall()
    res_map_name_to_id = {r["name"]: r["id"] for r in res_rows}
    res_map_id_to_platz = {r["id"]: r["platzbedarf"] for r in res_rows}
    
    # 2. Gebäude-Typen laden (name -> config)
    cur.execute("SELECT name, lagerkapazitaet, rohstoffverbrauch, produktion FROM gebaeude_typen")
    gt_rows = cur.fetchall()
    gt_map = {}
    for gt in gt_rows:
        gt_map[gt["name"]] = {
            "lagerkapazitaet": gt["lagerkapazitaet"],
            "verbrauch": safe_json(gt["rohstoffverbrauch"], []),
            "produktion": safe_json(gt["produktion"], [])
        }
        
    # 3. Provinzen iterieren
    cur.execute("SELECT id, name, world_x, world_y FROM provinzen WHERE player_id=?", (player_id,))
    provinzen = cur.fetchall()
    
    bericht = []
    
    for prov in provinzen:
        prov_id = prov["id"]
        
        cur.execute("SELECT building_x, building_y, building_type FROM buildings WHERE player_id=? AND world_x=? AND world_y=?", 
                    (player_id, prov["world_x"], prov["world_y"]))
        buildings = cur.fetchall()
        
        kapazitaet = 1000
        for b in buildings:
            if b["building_type"] in gt_map:
                kapazitaet += gt_map[b["building_type"]].get("lagerkapazitaet", 0)
                
        cur.execute("SELECT ressource_id, menge FROM provinz_lager WHERE provinz_id=?", (prov_id,))
        lager = {r["ressource_id"]: r["menge"] for r in cur.fetchall()}
        
        def get_used_platz(lager_dict):
            return sum(menge * res_map_id_to_platz.get(rid, 1) for rid, menge in lager_dict.items())
            
        prov_bericht = {"provinz_id": prov_id, "name": prov["name"] or f"({prov['world_x']},{prov['world_y']})", "gebaeude": []}
        
        for b in buildings:
            b_type = b["building_type"]
            if b_type not in gt_map: continue
                
            config = gt_map[b_type]
            verbrauch = config["verbrauch"]
            produktion = config["produktion"]
            
            # Prüfen ob Verbrauch gedeckt ist
            gedeck = True
            for v in verbrauch:
                res_name = v.get("ressource") or v.get("name")
                menge_gebraucht = v.get("menge", 0)
                if not res_name or menge_gebraucht <= 0: continue
                
                res_id = res_map_name_to_id.get(res_name)
                if not res_id or lager.get(res_id, 0) < menge_gebraucht:
                    gedeck = False
                    break
                    
            if not gedeck:
                prov_bericht["gebaeude"].append({
                    "koordinaten": f"{b['building_x']},{b['building_y']}",
                    "typ": b_type,
                    "status": "stillstand",
                    "grund": "Nicht genug Ressourcen"
                })
                continue
                
            # Rohstoffe abziehen
            for v in verbrauch:
                res_name = v.get("ressource") or v.get("name")
                menge_gebraucht = v.get("menge", 0)
                if not res_name or menge_gebraucht <= 0: continue
                res_id = res_map_name_to_id[res_name]
                lager[res_id] -= menge_gebraucht
                
            # Produktion hinzufügen
            produziert = []
            for p in produktion:
                res_name = p.get("ressource") or p.get("name")
                menge_prod = p.get("menge", 0)
                if not res_name or menge_prod <= 0: continue
                
                res_id = res_map_name_to_id.get(res_name)
                if not res_id: continue
                
                freier_platz = kapazitaet - get_used_platz(lager)
                if freier_platz <= 0: continue
                    
                platz_pro_einheit = res_map_id_to_platz.get(res_id, 1)
                max_aufnehmbar = math.floor(freier_platz / platz_pro_einheit)
                tatsaechliche_prod = min(menge_prod, max_aufnehmbar)
                
                if tatsaechliche_prod > 0:
                    lager[res_id] = lager.get(res_id, 0) + tatsaechliche_prod
                    produziert.append({"ressource": res_name, "menge": tatsaechliche_prod})
            
            prov_bericht["gebaeude"].append({
                "koordinaten": f"{b['building_x']},{b['building_y']}",
                "typ": b_type,
                "status": "produziert",
                "produziert": produziert
            })
            
        for rid, menge in lager.items():
            lager_set(cur, prov_id, rid, menge)
            
        bericht.append(prov_bericht)
    
    conn.commit()
    conn.close()
    
    return {"message": "Produktionsrunde abgeschlossen", "bericht": bericht}

@app.post("/player/{player_id}/roads/upgrade")
async def upgrade_road(player_id: int, upgrade: RoadUpgrade):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT iron FROM players WHERE id=?", (player_id,))
    player = cur.fetchone()
    if not player: conn.close(); raise HTTPException(404, "Spieler nicht gefunden")
    costs = CROSSING_COSTS if upgrade.road_type == "crossing" else ROAD_COSTS
    cost = costs.get(upgrade.new_level)
    if not cost: conn.close(); raise HTTPException(400, "Ungültiges Level")
    if player["iron"] < cost: conn.close(); raise HTTPException(400, "Nicht genug Eisen")
    try:
        cur.execute("SELECT id FROM roads WHERE player_id=? AND grid_x=? AND grid_y=?",
                    (player_id, upgrade.grid_x, upgrade.grid_y))
        ex = cur.fetchone()
        if ex: cur.execute("UPDATE roads SET level=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(upgrade.new_level,ex["id"]))
        else:  cur.execute("INSERT INTO roads (player_id,world_x,world_y,grid_x,grid_y,road_type,level) VALUES (?,25,25,?,?,?,?)",(player_id,upgrade.grid_x,upgrade.grid_y,upgrade.road_type,upgrade.new_level))
        cur.execute("UPDATE players SET iron=iron-? WHERE id=?", (cost, player_id))
        conn.commit()
        cur.execute("SELECT iron FROM players WHERE id=?", (player_id,))
        u = cur.fetchone(); conn.close()
        return {"message":f"Upgrade auf Level {upgrade.new_level}","remaining_iron":u["iron"]}
    except Exception as e: conn.rollback(); conn.close(); raise HTTPException(500, str(e))

@app.get("/player/{player_id}/province/{world_x}/{world_y}")
async def get_province_data(player_id: int, world_x: int, world_y: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT grid_x,grid_y,road_type,level FROM roads WHERE player_id=? AND world_x=? AND world_y=?",
                (player_id, world_x, world_y))
    roads = [{"grid_x":r["grid_x"],"grid_y":r["grid_y"],"road_type":r["road_type"],"level":r["level"]} for r in cur.fetchall()]
    cur.execute("SELECT building_x,building_y,building_type FROM buildings WHERE player_id=? AND world_x=? AND world_y=?",
                (player_id, world_x, world_y))
    bldgs = [{"building_x":b["building_x"],"building_y":b["building_y"],"building_type":b["building_type"],"icon":"🏗️"} for b in cur.fetchall()]
    conn.close()
    return {"roads":roads,"buildings":bldgs}

@app.post("/player/{player_id}/buildings")
async def build_building(player_id: int, building: BuildingCreate):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT iron FROM players WHERE id=?", (player_id,))
    player = cur.fetchone()
    if not player: conn.close(); raise HTTPException(404, "Spieler nicht gefunden")
    cost = BUILDING_COSTS.get(building.building_type)
    if not cost: conn.close(); raise HTTPException(400, "Ungültiger Gebäude-Typ")
    if player["iron"] < cost: conn.close(); raise HTTPException(400, "Nicht genug Eisen")
    try:
        cur.execute("INSERT INTO buildings (player_id,world_x,world_y,building_x,building_y,building_type) VALUES (?,25,25,?,?,?)",
                    (player_id, building.x, building.y, building.building_type))
        cur.execute("UPDATE players SET iron=iron-? WHERE id=?", (cost, player_id))
        conn.commit()
        cur.execute("SELECT iron FROM players WHERE id=?", (player_id,))
        u = cur.fetchone(); conn.close()
        return {"message":f"{building.building_type} gebaut","remaining_iron":u["iron"]}
    except sqlite3.IntegrityError: conn.close(); raise HTTPException(400, "Feld bereits bebaut")
    except Exception as e: conn.rollback(); conn.close(); raise HTTPException(500, str(e))

@app.delete("/player/{player_id}/buildings/{bx}/{by}")
async def remove_building(player_id: int, bx: int, by: int):
    conn = get_db(); cur = conn.cursor()
    try:
        cur.execute("DELETE FROM buildings WHERE player_id=? AND world_x=25 AND world_y=25 AND building_x=? AND building_y=?",
                    (player_id, bx, by))
        if cur.rowcount == 0: conn.close(); raise HTTPException(404, "Gebäude nicht gefunden")
        conn.commit(); conn.close()
        return {"message":"Gebäude entfernt"}
    except Exception as e: conn.rollback(); conn.close(); raise HTTPException(500, str(e))

# ─── Endpoints: Provinzen ─────────────────────────────────────────────────────
@app.get("/player/{player_id}/provinzen")
async def get_provinzen(player_id: int):
    """Alle Provinzen eines Spielers."""
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT id FROM players WHERE id=?", (player_id,))
    if not cur.fetchone(): conn.close(); raise HTTPException(404, "Spieler nicht gefunden")
    cur.execute("SELECT * FROM provinzen WHERE player_id=? ORDER BY id", (player_id,))
    provinzen = [fmt_provinz(r) for r in cur.fetchall()]
    conn.close()
    return {"player_id":player_id,"provinzen":provinzen,"anzahl":len(provinzen)}

@app.post("/player/{player_id}/provinzen")
async def provinz_beanspruchen(player_id: int, data: ProvinzCreate):
    """Eine Weltkarte-Provinz beanspruchen (muss noch unbesetzt sein)."""
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT id FROM players WHERE id=?", (player_id,))
    if not cur.fetchone(): conn.close(); raise HTTPException(404, "Spieler nicht gefunden")
    cur.execute("SELECT id,player_id FROM provinzen WHERE world_x=? AND world_y=?",
                (data.world_x, data.world_y))
    ex = cur.fetchone()
    if ex:
        conn.close()
        if ex["player_id"] == player_id:
            raise HTTPException(409, "Du besitzt diese Provinz bereits")
        raise HTTPException(409, f"Diese Provinz gehört bereits Spieler {ex['player_id']}")
    try:
        cur.execute("INSERT INTO provinzen (player_id,world_x,world_y,name) VALUES (?,?,?,?)",
                    (player_id, data.world_x, data.world_y, data.name or ""))
        provinz_id = cur.lastrowid
        conn.commit()
        cur.execute("SELECT * FROM provinzen WHERE id=?", (provinz_id,))
        p = cur.fetchone(); conn.close()
        return {"message":"Provinz beansprucht","provinz":fmt_provinz(p)}
    except Exception as e: conn.rollback(); conn.close(); raise HTTPException(500, str(e))

@app.get("/player/{player_id}/provinzen/{provinz_id}")
async def get_provinz(player_id: int, provinz_id: int):
    """Provinz-Details inkl. Lager-Übersicht."""
    conn = get_db(); cur = conn.cursor()
    p = get_provinz_or_403(cur, player_id, provinz_id)
    # Lager-Gesamtwert
    cur.execute("""SELECT SUM(pl.menge * r.wert) as gesamtwert, COUNT(*) as positionen
                   FROM provinz_lager pl JOIN ressourcen r ON pl.ressource_id=r.id
                   WHERE pl.provinz_id=? AND pl.menge>0""", (provinz_id,))
    stats = cur.fetchone(); conn.close()
    result = fmt_provinz(p)
    result["lager_gesamtwert"] = stats["gesamtwert"] or 0
    result["lager_positionen"] = stats["positionen"] or 0
    return result

# ─── Endpoints: Provinz-Lager ─────────────────────────────────────────────────
@app.get("/player/{player_id}/provinzen/{provinz_id}/lager")
async def get_lager(player_id: int, provinz_id: int, typ: Optional[str] = None):
    """Ressourcen-Lager einer Provinz (nur eigene Provinzen)."""
    conn = get_db(); cur = conn.cursor()
    p = get_provinz_or_403(cur, player_id, provinz_id)
    
    sql = """SELECT pl.ressource_id, r.name as ressource_name, r.typ, r.wert, r.platzbedarf, pl.menge
             FROM provinz_lager pl
             JOIN ressourcen r ON pl.ressource_id = r.id
             WHERE pl.provinz_id=? AND pl.menge>0"""
    params = [provinz_id]
    if typ:
        sql += " AND r.typ=?"; params.append(typ)
    sql += " ORDER BY r.typ, r.name"
    cur.execute(sql, params)
    eintraege = [fmt_lager_eintrag(r) for r in cur.fetchall()]
    gesamtwert = sum(e["gesamtwert"] for e in eintraege)
    
    # Kapazität berechnen
    cur.execute("SELECT building_type FROM buildings WHERE player_id=? AND world_x=? AND world_y=?",
                (player_id, p["world_x"], p["world_y"]))
    buildings = cur.fetchall()
    
    kapazitaet = 1000
    for b in buildings:
        cur.execute("SELECT lagerkapazitaet FROM gebaeude_typen WHERE name=?", (b["building_type"],))
        gt = cur.fetchone()
        if gt: kapazitaet += gt["lagerkapazitaet"]
    
    conn.close()
    return {"provinz_id":provinz_id,"eintraege":eintraege,
            "anzahl_positionen":len(eintraege),"gesamtwert":gesamtwert, "kapazitaet": kapazitaet}

@app.put("/player/{player_id}/provinzen/{provinz_id}/lager/{ressource_id}")
async def lager_ressource_setzen(player_id: int, provinz_id: int, ressource_id: int, data: LagerUpdate):
    """Absolute Menge einer Ressource im Lager setzen."""
    conn = get_db(); cur = conn.cursor()
    get_provinz_or_403(cur, player_id, provinz_id)
    cur.execute("SELECT id,name FROM ressourcen WHERE id=?", (ressource_id,))
    res = cur.fetchone()
    if not res: conn.close(); raise HTTPException(404, "Ressource nicht gefunden")
    if data.menge < 0: conn.close(); raise HTTPException(400, "Menge darf nicht negativ sein")
    try:
        lager_set(cur, provinz_id, ressource_id, data.menge)
        conn.commit(); conn.close()
        return {"message":f"{res['name']}: Menge auf {data.menge} gesetzt",
                "provinz_id":provinz_id,"ressource_id":ressource_id,"menge":data.menge}
    except Exception as e: conn.rollback(); conn.close(); raise HTTPException(500, str(e))

@app.patch("/player/{player_id}/provinzen/{provinz_id}/lager/{ressource_id}")
async def lager_ressource_aendern(player_id: int, provinz_id: int, ressource_id: int, data: LagerDelta):
    """Menge einer Ressource um delta ändern (+/-)."""
    conn = get_db(); cur = conn.cursor()
    get_provinz_or_403(cur, player_id, provinz_id)
    cur.execute("SELECT id,name FROM ressourcen WHERE id=?", (ressource_id,))
    res = cur.fetchone()
    if not res: conn.close(); raise HTTPException(404, "Ressource nicht gefunden")
    alte_menge = get_lager_menge(cur, provinz_id, ressource_id)
    neue_menge = alte_menge + data.delta
    if neue_menge < 0:
        conn.close()
        raise HTTPException(400, f"Nicht genug {res['name']} im Lager (vorhanden: {alte_menge}, benötigt: {-data.delta})")
    try:
        lager_set(cur, provinz_id, ressource_id, neue_menge)
        conn.commit(); conn.close()
        return {"message":f"{res['name']}: {alte_menge} → {neue_menge}",
                "provinz_id":provinz_id,"ressource_id":ressource_id,
                "alte_menge":alte_menge,"neue_menge":neue_menge,"delta":data.delta}
    except Exception as e: conn.rollback(); conn.close(); raise HTTPException(500, str(e))

# ─── Endpoints: Handelskarren-Transport ───────────────────────────────────────
@app.post("/player/{player_id}/provinzen/{provinz_id}/transport")
async def transport_senden(player_id: int, provinz_id: int, data: TransportRequest):
    """
    Ressourcen per Handelskarren von einer Provinz in eine andere transportieren.

    Regeln:
    - Quell- und Ziel-Provinz müssen dem Spieler gehören
    - Quell-Provinz braucht genug Handelskarren (ID=1)
    - Jeder Karren trägt 50 Platz; platzbedarf der Ressource wird berücksichtigt
    - Karren reisen MIT den Waren (Quell-Lager −karren, Ziel-Lager +karren)
    - Transport ist sofort (kein Runden-Delay)
    """
    if data.menge <= 0:
        raise HTTPException(400, "Menge muss > 0 sein")
    if data.nach_provinz_id == provinz_id:
        raise HTTPException(400, "Quell- und Ziel-Provinz sind identisch")

    conn = get_db(); cur = conn.cursor()

    # Provinzen prüfen
    von_p = get_provinz_or_403(cur, player_id, provinz_id)
    nach_p = get_provinz_or_403(cur, player_id, data.nach_provinz_id)

    # Ressource prüfen
    cur.execute("SELECT * FROM ressourcen WHERE id=?", (data.ressource_id,))
    res = cur.fetchone()
    if not res: conn.close(); raise HTTPException(404, "Ressource nicht gefunden")

    # Handelskarren können sich nicht selbst transportieren
    if data.ressource_id == HANDELSKARREN_ID:
        conn.close()
        raise HTTPException(400, "Handelskarren können nicht als Ware transportiert werden. Nutze delta-Lager direkt.")

    # Verfügbare Menge prüfen
    vorhandene_menge = get_lager_menge(cur, provinz_id, data.ressource_id)
    if vorhandene_menge < data.menge:
        conn.close()
        raise HTTPException(400, f"Nicht genug {res['name']} in Provinz {von_p['name'] or provinz_id} "
                                  f"(vorhanden: {vorhandene_menge}, benötigt: {data.menge})")

    # Benötigte Karren berechnen
    platz_benoetigt = data.menge * res["platzbedarf"]
    karren_benoetigt = math.ceil(platz_benoetigt / HANDELSKARREN_KAPAZITÄT)

    # Handelskarren im Quell-Lager prüfen
    karren_vorhanden = get_lager_menge(cur, provinz_id, HANDELSKARREN_ID)
    if karren_vorhanden < karren_benoetigt:
        conn.close()
        raise HTTPException(400,
            f"Nicht genug Handelskarren in Provinz {von_p['name'] or provinz_id}. "
            f"Benötigt: {karren_benoetigt} (à 50 Platz, Ware braucht {platz_benoetigt} Platz), "
            f"Vorhanden: {karren_vorhanden}")

    try:
        # Quell-Lager: Ware + Karren abziehen
        lager_set(cur, provinz_id, data.ressource_id, vorhandene_menge - data.menge)
        lager_set(cur, provinz_id, HANDELSKARREN_ID, karren_vorhanden - karren_benoetigt)

        # Ziel-Lager: Ware + Karren hinzufügen
        ziel_ware = get_lager_menge(cur, data.nach_provinz_id, data.ressource_id)
        ziel_karren = get_lager_menge(cur, data.nach_provinz_id, HANDELSKARREN_ID)
        lager_set(cur, data.nach_provinz_id, data.ressource_id, ziel_ware + data.menge)
        lager_set(cur, data.nach_provinz_id, HANDELSKARREN_ID, ziel_karren + karren_benoetigt)

        # Transport-Log
        cur.execute("""INSERT INTO handelskarren_transport
                       (player_id,von_provinz_id,nach_provinz_id,ressource_id,menge,karren_benoetigt,status)
                       VALUES (?,?,?,?,?,?,'angekommen')""",
                    (player_id,provinz_id,data.nach_provinz_id,data.ressource_id,data.menge,karren_benoetigt))
        transport_id = cur.lastrowid
        conn.commit()

        # Neue Lagerstände für Response
        conn2 = get_db(); cur2 = conn2.cursor()
        neue_menge_von  = get_lager_menge(cur2, provinz_id, data.ressource_id)
        neue_menge_nach = get_lager_menge(cur2, data.nach_provinz_id, data.ressource_id)
        conn2.close(); conn.close()

        return {
            "message": f"{data.menge}× {res['name']} transportiert",
            "transport_id": transport_id,
            "von_provinz": {"id":provinz_id, "name":von_p["name"] or f"({von_p['world_x']},{von_p['world_y']})", "neue_menge":neue_menge_von},
            "nach_provinz": {"id":data.nach_provinz_id, "name":nach_p["name"] or f"({nach_p['world_x']},{nach_p['world_y']})", "neue_menge":neue_menge_nach},
            "karren_benutzt": karren_benoetigt,
            "platz_benutzt": platz_benoetigt
        }
    except HTTPException: conn.rollback(); conn.close(); raise
    except Exception as e: conn.rollback(); conn.close(); raise HTTPException(500, str(e))

@app.get("/player/{player_id}/transport")
async def get_transporte(player_id: int, limit: int = 50):
    """Transport-Verlauf eines Spielers (neueste zuerst)."""
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT id FROM players WHERE id=?", (player_id,))
    if not cur.fetchone(): conn.close(); raise HTTPException(404, "Spieler nicht gefunden")
    cur.execute("""
        SELECT t.id, t.menge, t.karren_benoetigt, t.status, t.created_at,
               r.name as ressource_name, r.typ as ressource_typ,
               vp.world_x as von_x, vp.world_y as von_y, vp.name as von_name,
               np.world_x as nach_x, np.world_y as nach_y, np.name as nach_name
        FROM handelskarren_transport t
        JOIN ressourcen r ON t.ressource_id=r.id
        JOIN provinzen vp ON t.von_provinz_id=vp.id
        JOIN provinzen np ON t.nach_provinz_id=np.id
        WHERE t.player_id=?
        ORDER BY t.id DESC LIMIT ?
    """, (player_id, limit))
    rows = cur.fetchall(); conn.close()
    return {"player_id":player_id,"transporte":[{
        "id":r["id"],"ressource":r["ressource_name"],"typ":r["ressource_typ"],
        "menge":r["menge"],"karren":r["karren_benoetigt"],"status":r["status"],
        "von": f"{r['von_name'] or f'({r["von_x"]},{r["von_y"]})'} ({r['von_x']},{r['von_y']})",
        "nach":f"{r['nach_name'] or f'({r["nach_x"]},{r["nach_y"]})'} ({r['nach_x']},{r['nach_y']})",
        "datum":r["created_at"]
    } for r in rows]}

# ─── Endpoints: Gebäude-Typen ─────────────────────────────────────────────────
@app.get("/gebaeude")
async def get_gebaeude_typen(kategorie: Optional[str]=None, bautyp: Optional[str]=None,
                              baubar: Optional[bool]=None, terrain: Optional[str]=None):
    conn = get_db(); cur = conn.cursor()
    sql = "SELECT * FROM gebaeude_typen WHERE 1=1"; params = []
    if kategorie: sql+=" AND kategorie=?"; params.append(kategorie)
    if bautyp:    sql+=" AND bautyp=?";    params.append(bautyp)
    if baubar is not None: sql+=" AND baubar=?"; params.append(int(baubar))
    sql += " ORDER BY id"
    cur.execute(sql, params); rows = cur.fetchall(); conn.close()
    results = [fmt_gebaeude(r) for r in rows]
    if terrain:
        out = []
        for g in results:
            for ts in g["terrain_effektivitaet"].values():
                if terrain in ts: out.append(g); break
        return out
    return results

@app.get("/gebaeude/{gebaeude_id}")
async def get_gebaeude(gebaeude_id: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT * FROM gebaeude_typen WHERE id=?", (gebaeude_id,))
    row = cur.fetchone(); conn.close()
    if not row: raise HTTPException(404, "Gebäude nicht gefunden")
    return fmt_gebaeude(row)

# ─── Endpoints: Provinz-Feldtypen ─────────────────────────────────────────────
@app.get("/provinz/feldtypen")
async def get_feldtypen():
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT * FROM provinz_feldtypen ORDER BY id")
    rows = cur.fetchall(); conn.close()
    return [{"id":r["id"],"name":r["name"],"beschreibung":r["beschreibung"],
             "groesse_px":r["groesse_px"],"ist_baubar":bool(r["ist_baubar"]),
             "bautypen":safe_json(r["bautypen"],[]),"farbe_leer":r["farbe_leer"]} for r in rows]

@app.get("/provinz/feldtypen/{feldtyp_id}")
async def get_feldtyp(feldtyp_id: str):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT * FROM provinz_feldtypen WHERE id=?", (feldtyp_id,))
    row = cur.fetchone()
    if not row: conn.close(); raise HTTPException(404, "Feldtyp nicht gefunden")
    bautypen = safe_json(row["bautypen"], [])
    baubare = []
    for bt in bautypen:
        cur.execute("SELECT * FROM gebaeude_typen WHERE bautyp=? AND baubar=1 ORDER BY tech_level,id",(bt,))
        baubare.extend([fmt_gebaeude(r) for r in cur.fetchall()])
    conn.close()
    return {"id":row["id"],"name":row["name"],"beschreibung":row["beschreibung"],
            "groesse_px":row["groesse_px"],"ist_baubar":bool(row["ist_baubar"]),
            "bautypen":bautypen,"farbe_leer":row["farbe_leer"],"baubare_gebaeude":baubare}

# ─── Endpoints: Ressourcen ────────────────────────────────────────────────────
@app.get("/ressourcen/typen")
async def get_ressourcen_typen():
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT DISTINCT typ, COUNT(*) as anzahl FROM ressourcen GROUP BY typ ORDER BY typ")
    rows = cur.fetchall(); conn.close()
    return [{"typ":r["typ"],"anzahl":r["anzahl"]} for r in rows]

@app.get("/ressourcen")
async def get_ressourcen(typ: Optional[str]=None, name: Optional[str]=None):
    conn = get_db(); cur = conn.cursor()
    sql = "SELECT * FROM ressourcen WHERE 1=1"; params = []
    if typ:  sql+=" AND typ=?";       params.append(typ)
    if name: sql+=" AND name LIKE ?"; params.append(f"%{name}%")
    sql += " ORDER BY typ,name"
    cur.execute(sql, params); rows = cur.fetchall(); conn.close()
    return [fmt_ressource(r) for r in rows]

@app.get("/ressourcen/{ressource_id}")
async def get_ressource(ressource_id: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT * FROM ressourcen WHERE id=?", (ressource_id,))
    row = cur.fetchone(); conn.close()
    if not row: raise HTTPException(404, "Ressource nicht gefunden")
    return fmt_ressource(row)

# ─── Endpoints: Vorkommen ─────────────────────────────────────────────────────
@app.get("/vorkommen/typen")
async def get_vorkommen_typen():
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT DISTINCT typ, COUNT(*) as anzahl FROM vorkommen GROUP BY typ ORDER BY typ")
    rows = cur.fetchall(); conn.close()
    return [{"typ":r["typ"],"anzahl":r["anzahl"]} for r in rows]

@app.get("/vorkommen")
async def get_vorkommen(typ: Optional[str]=None, name: Optional[str]=None):
    conn = get_db(); cur = conn.cursor()
    sql = "SELECT * FROM vorkommen WHERE 1=1"; params = []
    if typ:  sql+=" AND typ=?";       params.append(typ)
    if name: sql+=" AND name LIKE ?"; params.append(f"%{name}%")
    sql += " ORDER BY tech,name"
    cur.execute(sql, params); rows = cur.fetchall(); conn.close()
    return [fmt_vorkommen(r) for r in rows]

@app.get("/vorkommen/{vorkommen_id}")
async def get_vorkommen_by_id(vorkommen_id: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT * FROM vorkommen WHERE id=?", (vorkommen_id,))
    row = cur.fetchone(); conn.close()
    if not row: raise HTTPException(404, "Vorkommen nicht gefunden")
    return fmt_vorkommen(row)

# ─── Static Files (NACH makedirs + init_db!) ──────────────────────────────────
app.mount("/css",      StaticFiles(directory="css"),      name="css")
app.mount("/js",       StaticFiles(directory="js"),       name="js")
app.mount("/terrains", StaticFiles(directory="terrains"), name="terrains")

if __name__ == "__main__":
    import uvicorn
    print("🚀 Verbrannte Zone Backend v2.1.0")
    uvicorn.run(app, host="0.0.0.0", port=8000)
