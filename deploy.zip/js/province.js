// province.js - Provinzlogik mit Terrain-System

const BUILDING_FIELDS = 15;
const GRID_SIZE = 31;
const BUILDING_CELL_SIZE = 45;
const ROAD_CELL_SIZE = 15;
const CROSSING_CELL_SIZE = 15;

const OBJECT_TYPES = {
    CROSSING: 'crossing',
    ROAD: 'road',
    BUILDING: 'building'
};

const ROAD_LEVELS = {
    1: { name: 'Feldweg', color: '#8b7355', cost: 50 },
    2: { name: 'Kiesweg', color: '#9d8566', cost: 100 },
    3: { name: 'Pflasterweg', color: '#a89784', cost: 200 },
    4: { name: 'Betonweg', color: '#b8b8b8', cost: 400 }
};

const CROSSING_LEVELS = {
    1: { name: 'Feldwegkreuzung', color: '#7a6345', cost: 100 },
    2: { name: 'Kieskreuzung', color: '#8d7556', cost: 200 },
    3: { name: 'Pflasterkreuzung', color: '#988774', cost: 400 },
    4: { name: 'Betonkreuzung', color: '#a8a8a8', cost: 800 }
};

// Lädt und zeigt eine Provinz-Ansicht
function loadProvince(worldX, worldY) {
    console.log(`📍 Lade Provinz (${worldX}, ${worldY})`);

    // Hole Terrain-Typ der Provinz
    const provinceTerrain = window.WORLD_MAP[worldY][worldX];
    console.log(`🗺️  Terrain: ${provinceTerrain}`);

    // Speichere für späteren Zugriff
    window.currentProvinceTerrain = provinceTerrain;

    const container = document.getElementById('province-grid');
    container.innerHTML = '';
    container.style.display = 'grid';

    const template = buildGridTemplate();
    container.style.gridTemplateColumns = template;
    container.style.gridTemplateRows = template;
    container.style.gap = '0';

    const provinceData = generateProvinceData(worldX, worldY, provinceTerrain);

    // Rendere Grid
    for (let gridY = 0; gridY < GRID_SIZE; gridY++) {
        for (let gridX = 0; gridX < GRID_SIZE; gridX++) {
            const cell = document.createElement('div');
            cell.className = 'province-cell';
            cell.dataset.gridX = gridX;
            cell.dataset.gridY = gridY;

            const cellData = provinceData[gridY][gridX];
            const cellType = cellData.cellType;

            if (cellType === 'road') {
                const level = cellData.level || 1;
                cell.style.backgroundColor = ROAD_LEVELS[level].color;
                cell.style.fontSize = '10px';
                cell.style.color = '#3a2a1a';
                cell.textContent = 'W';
                cell.title = `${ROAD_LEVELS[level].name} (${gridX}, ${gridY})`;
            } else if (cellType === 'crossing') {
                const level = cellData.level || 1;
                cell.style.backgroundColor = CROSSING_LEVELS[level].color;
                cell.style.fontSize = '8px';
                cell.style.color = '#2a1a0a';
                cell.textContent = 'K';
                cell.title = `${CROSSING_LEVELS[level].name} (${gridX}, ${gridY})`;
            } else if (cellType === 'building') {
                const terrain = cellData.terrain;
                cell.style.backgroundColor = getTerrainColor(terrain);
                cell.title = `Gebäudefeld (${cellData.buildingX}, ${cellData.buildingY})`;

                if (cellData.placedBuilding) {
                    const icon = document.createElement('div');
                    icon.className = 'placed-building-icon';
                    icon.textContent = cellData.placedBuilding.icon;
                    icon.style.fontSize = '28px';
                    icon.style.textShadow = '0 0 3px black';
                    cell.style.display = 'flex';
                    cell.style.alignItems = 'center';
                    cell.style.justifyContent = 'center';
                    cell.appendChild(icon);
                }
            }

            cell.dataset.cellType = cellType;
            cell.onclick = () => selectProvinceCell(cellData);
            container.appendChild(cell);
        }
    }

    // Info-Panel aktualisieren mit Terrain-Info
    updateProvinceInfo(worldX, worldY, provinceTerrain);
}

function updateProvinceInfo(x, y, terrainType) {
    const terrain = window.TERRAIN_TYPES ? window.TERRAIN_TYPES[terrainType] : null;

    let infoHTML = `<p><strong>Provinz:</strong> (${x}, ${y})</p>`;

    if (terrain) {
        infoHTML += `<p><strong>Terrain:</strong> ${terrain.icon} ${terrain.name}</p>`;
        infoHTML += `<p><strong>Ressourcen:</strong> ${terrain.resources.join(', ') || 'Keine'}</p>`;
        infoHTML += `<p style="font-size: 11px; color: var(--text-muted);">${terrain.description}</p>`;
    }

    infoHTML += `<hr style="margin: 10px 0; border-color: var(--border);">`;
    infoHTML += `<p style="font-size: 11px;">Klicke auf ein Feld für Details.</p>`;

    document.getElementById('selected-info').innerHTML = infoHTML;
}

function buildGridTemplate() {
    const parts = [];
    for (let i = 0; i < GRID_SIZE; i++) {
        if (i % 2 === 0) {
            parts.push(`${ROAD_CELL_SIZE}px`);
        } else {
            parts.push(`${BUILDING_CELL_SIZE}px`);
        }
    }
    return parts.join(' ');
}

function generateProvinceData(worldX, worldY, provinceTerrain) {
    const data = [];

    for (let gridY = 0; gridY < GRID_SIZE; gridY++) {
        const row = [];
        for (let gridX = 0; gridX < GRID_SIZE; gridX++) {
            let cellData = {};

            if (gridX % 2 === 0 && gridY % 2 === 0) {
                cellData = {
                    cellType: 'crossing',
                    gridX: gridX,
                    gridY: gridY,
                    level: 1
                };
            } else if (gridX % 2 === 0 || gridY % 2 === 0) {
                cellData = {
                    cellType: 'road',
                    gridX: gridX,
                    gridY: gridY,
                    level: 1
                };
            } else {
                const buildingX = Math.floor(gridX / 2);
                const buildingY = Math.floor(gridY / 2);
                cellData = {
                    cellType: 'building',
                    gridX: gridX,
                    gridY: gridY,
                    buildingX: buildingX,
                    buildingY: buildingY,
                    terrain: provinceTerrain,
                    placedBuilding: null
                };
            }

            row.push(cellData);
        }
        data.push(row);
    }

    return data;
}

function selectProvinceCell(cellData) {
    let infoHTML = `<p><strong>Position:</strong> (${cellData.gridX}, ${cellData.gridY})</p>`;

    const cellType = cellData.cellType;

    if (cellType === 'crossing') {
        const currentLevel = cellData.level || 1;
        const levelInfo = CROSSING_LEVELS[currentLevel];
        infoHTML += `<p><strong>Typ:</strong> Kreuzung</p>`;
        infoHTML += `<p><strong>Stufe:</strong> ${currentLevel} - ${levelInfo.name}</p>`;

        if (currentLevel < 4) {
            const nextLevel = currentLevel + 1;
            const nextLevelInfo = CROSSING_LEVELS[nextLevel];
            infoHTML += `<p style="color: var(--accent-warning);">⬆️ Upgrade: ${nextLevelInfo.name} (${nextLevelInfo.cost} Eisen)</p>`;
        } else {
            infoHTML += `<p style="color: var(--accent-success);">🏆 Maximale Stufe!</p>`;
        }
    } else if (cellType === 'road') {
        const currentLevel = cellData.level || 1;
        const levelInfo = ROAD_LEVELS[currentLevel];
        infoHTML += `<p><strong>Typ:</strong> Weg</p>`;
        infoHTML += `<p><strong>Stufe:</strong> ${currentLevel} - ${levelInfo.name}</p>`;

        if (currentLevel < 4) {
            const nextLevel = currentLevel + 1;
            const nextLevelInfo = ROAD_LEVELS[nextLevel];
            infoHTML += `<p style="color: var(--accent-warning);">⬆️ Upgrade: ${nextLevelInfo.name} (${nextLevelInfo.cost} Eisen)</p>`;
        } else {
            infoHTML += `<p style="color: var(--accent-success);">🏆 Maximale Stufe!</p>`;
        }
    } else if (cellType === 'building') {
        const buildingX = cellData.buildingX;
        const buildingY = cellData.buildingY;
        const terrain = cellData.terrain;

        infoHTML += `<p><strong>Typ:</strong> Gebäudefeld</p>`;
        infoHTML += `<p><strong>Position:</strong> (${buildingX}, ${buildingY})</p>`;

        if (cellData.placedBuilding) {
            const building = cellData.placedBuilding;
            infoHTML += `<p><strong>Gebäude:</strong> ${building.icon} ${building.name}</p>`;
            infoHTML += `<p style="font-size: 11px;">${building.description}</p>`;
        } else {
            infoHTML += `<p style="color: var(--accent-success);">✅ Bebaubar!</p>`;

            // Zeige baubare Gebäude für dieses Terrain
            if (window.TERRAIN_TYPES && window.BUILDING_TYPES) {
                const terrainInfo = window.TERRAIN_TYPES[terrain];
                const allowedBuildings = terrainInfo.allowedBuildings;

                infoHTML += `<hr style="margin: 10px 0; border-color: var(--border);">`;
                infoHTML += `<p><strong>Baubare Gebäude:</strong></p>`;

                if (allowedBuildings.length > 0) {
                    allowedBuildings.forEach(buildingId => {
                        const building = window.BUILDING_TYPES[buildingId];
                        if (building) {
                            infoHTML += `<p style="font-size: 11px;">• ${building.icon} ${building.name}</p>`;
                        }
                    });
                } else {
                    infoHTML += `<p style="font-size: 11px; color: var(--text-muted);">Keine Gebäude möglich</p>`;
                }
            }
        }
    }

    document.getElementById('selected-info').innerHTML = infoHTML;
}

function getTerrainColor(terrain) {
    if (window.TERRAIN_TYPES && window.TERRAIN_TYPES[terrain]) {
        return window.TERRAIN_TYPES[terrain].color;
    }
    return '#5a8c3a';
}

function backToWorld() {
    if (typeof window.switchView === 'function') {
        window.switchView('world');
    }
}

// Exportiere Funktionen
if (typeof window !== 'undefined') {
    window.loadProvince = loadProvince;
    window.backToWorld = backToWorld;
}
