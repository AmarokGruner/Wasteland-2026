// ============================================================
// Hauptlogik – Verbrannte Zone
// ============================================================

const APIBASE = 'http://localhost:8000';
window.APIBASE             = APIBASE;
window.currentPlayerId     = 1;
window.currentView         = 'world';
window.selectedProvinceCoords = null;
window.currentProvinzId    = null;

// ── Initialisierung ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  console.log('Verbrannte Zone lädt...');
  loadResources();
  initWorldMap();
  switchView('world');
});

// ── Spieler-Ressourcen laden ─────────────────────────────────
async function loadResources() {
  try {
    const response = await fetch(`${APIBASE}/player/${window.currentPlayerId}`);
    if (response.ok) {
      const data = await response.json();
      document.getElementById('iron-count').textContent  = data.iron;
      document.getElementById('steel-count').textContent = data.steel;
      document.getElementById('fuel-count').textContent  = data.fuel;
    }
  } catch (error) {
    console.error('Fehler beim Laden der Ressourcen', error);
  }
}

// ── Zwischen Weltkarte und Provinzansicht wechseln ───────────
function switchView(view, x = null, y = null) {
  window.currentView = view;

  document.getElementById('worldmap-view').style.display  = view === 'world'    ? 'flex' : 'none';
  document.getElementById('province-view').style.display  = view === 'province' ? 'flex' : 'none';
  document.getElementById('sidebar-world-content').style.display    = view === 'world'    ? 'block' : 'none';
  document.getElementById('sidebar-province-content').style.display = view === 'province' ? 'block' : 'none';

  if (view === 'province' && x !== null && y !== null) {
    window.selectedProvinceCoords = { x, y };
    window.currentProvinzId = null;
    if (typeof window.loadProvince === 'function') window.loadProvince(x, y);
    showProvinceSubView('map');
    resolveProvinzId(x, y);
  } else if (view === 'world') {
    window.selectedProvinceCoords = null;
    window.currentProvinzId = null;
    document.getElementById('selected-info').innerHTML =
      '<p>Wähle eine Provinz aus, um sie zu verwalten.</p>';
  }
}

// ── Provinz-ID aus Backend holen und cachen ──────────────────
// Backend: GET /player/{id}/provinzen
// Response: { player_id, provinzen: [{id, world_x, world_y, name, ...}], anzahl }
async function resolveProvinzId(x, y) {
  try {
    const url = `${APIBASE}/player/${window.currentPlayerId}/provinzen`;
    const res = await fetch(url);
    if (!res.ok) { console.warn(`resolveProvinzId: HTTP ${res.status}`); return; }
    const data = await res.json();
    // ⚠️ Response ist { provinzen: [...] }, NICHT direkt ein Array
    const prov = data.provinzen.find(p => p.world_x === x && p.world_y === y);
    if (prov) {
      window.currentProvinzId = prov.id;
      console.log(`Provinz-ID gecacht: ${prov.id} für (${x},${y})`);
    } else {
      console.warn(`Keine Provinz für (${x},${y}) im Backend. Beansprucht?`);
    }
  } catch (e) {
    console.warn('resolveProvinzId fehlgeschlagen:', e.message);
  }
}

// ── Sub-View Provinz umschalten ──────────────────────────────
function showProvinceSubView(sub) {
  const mapContainer   = document.getElementById('province-map-container');
  const lagerContainer = document.getElementById('province-lager-container');
  const btnMap         = document.getElementById('menu-btn-map');
  const btnLager       = document.getElementById('menu-btn-lager');

  if (sub === 'map') {
    mapContainer.style.display   = 'block';
    lagerContainer.style.display = 'none';
    btnMap.classList.add('active');
    btnLager.classList.remove('active');
  } else if (sub === 'lager') {
    mapContainer.style.display   = 'none';
    lagerContainer.style.display = 'block';
    btnMap.classList.remove('active');
    btnLager.classList.add('active');
    loadProvinceLager();
  }
}

// ── Lagerbestand laden ───────────────────────────────────────
// Backend-Responses:
//   /provinzen       → { player_id, provinzen: [...], anzahl }
//   /provinzen/{id}/lager → { provinz_id, eintraege: [{ressource_name, typ, menge, ...}], anzahl_positionen, gesamtwert }
async function loadProvinceLager() {
  const lagerContent = document.getElementById('lager-content');
  const coords = window.selectedProvinceCoords;

  if (!coords) {
    lagerContent.innerHTML = '<p style="color:var(--text-muted)">Keine Provinz ausgewählt.</p>';
    return;
  }

  lagerContent.innerHTML = '<p style="color:var(--text-muted)">Lade Lager...</p>';

  try {
    // Provinz-ID: gecacht oder nachladen
    let provinzId = window.currentProvinzId;

    if (!provinzId) {
      const listUrl = `${APIBASE}/player/${window.currentPlayerId}/provinzen`;
      const listRes = await fetch(listUrl);
      if (!listRes.ok) throw new Error(`GET ${listUrl} → HTTP ${listRes.status}`);
      const listData = await listRes.json();
      // Response: { player_id, provinzen: [...], anzahl }  ← Array ist unter .provinzen
      const prov = listData.provinzen.find(p => p.world_x === coords.x && p.world_y === coords.y);
      if (!prov) throw new Error(
        `Provinz (${coords.x},${coords.y}) nicht im Backend. ` +
        `POST /player/1/provinzen ausgeführt?`
      );
      provinzId = prov.id;
      window.currentProvinzId = provinzId;
    }

    // Lagereinträge laden
    const lagerUrl = `${APIBASE}/player/${window.currentPlayerId}/provinzen/${provinzId}/lager`;
    const lagerRes = await fetch(lagerUrl);
    if (!lagerRes.ok) throw new Error(`GET ${lagerUrl} → HTTP ${lagerRes.status}`);
    const lagerData = await lagerRes.json();
    // Response: { provinz_id, eintraege: [...], anzahl_positionen, gesamtwert }
    // Backend filtert bereits WHERE menge > 0, kein eigener Filter nötig
    const eintraege = lagerData.eintraege;

    // Kapazitätsbalken
    const totalMenge = eintraege.reduce((sum, i) => sum + i.menge, 0);
    const kapazitaet = lagerData.kapazitaet || 1000;
    const prozent    = Math.min(100, Math.round((totalMenge / kapazitaet) * 100));
    const barColor   = prozent > 80 ? '#ff4444' : prozent > 50 ? '#ffaa00' : '#48bb78';

    let html = `
      <div class="lager-header"><h2>🏪 Provinzlager</h2></div>
      <div class="lager-kapazitaet">
        <div class="lager-bar-label">
          <span>Kapazität</span>
          <span>${totalMenge.toLocaleString('de-DE')} / ${kapazitaet.toLocaleString('de-DE')}</span>
        </div>
        <div class="lager-bar-bg">
          <div class="lager-bar-fill" style="width:${prozent}%; background:${barColor}"></div>
        </div>
      </div>`;

    if (eintraege.length === 0) {
      html += '<p style="color:var(--text-muted); margin-top:12px">Lager ist leer.</p>';
    } else {
      html += `
        <table class="lager-tabelle">
          <thead><tr><th>Ressource</th><th style="text-align:right">Menge</th></tr></thead>
          <tbody>
            ${eintraege.map(item => `
              <tr>
                <td>
                  ${item.ressource_name}
                  ${item.typ ? `<span class="lager-typ">${item.typ}</span>` : ''}
                </td>
                <td class="lager-menge">${item.menge.toLocaleString('de-DE')}</td>
              </tr>`).join('')}
          </tbody>
        </table>`;
    }

    lagerContent.innerHTML = html;

  } catch (error) {
    console.error('Fehler Lager:', error);
    lagerContent.innerHTML = `
      <div style="color:var(--accent-danger); font-size:0.9rem; line-height:1.8">
        <strong>⚠️ Lager konnte nicht geladen werden</strong><br>
        ${error.message}
      </div>`;
  }
}

async function nextTurn() {
  try {
    const response = await fetch(
      `${APIBASE}/player/${window.currentPlayerId}/resources/produce`,
      { method: 'POST' }
    );
    if (response.ok) {
      const data = await response.json();
      let summary = 'Produktionsrunde abgeschlossen!\n\n';
      
      if (data.bericht && data.bericht.length > 0) {
        data.bericht.forEach(prov => {
          let produced = 0;
          let stopped = 0;
          prov.gebaeude.forEach(b => {
             if(b.status === 'produziert') produced++;
             if(b.status === 'stillstand') stopped++;
          });
          if(produced > 0 || stopped > 0) {
             summary += `${prov.name}: ${produced} Gebäude produziert, ${stopped} stillgestanden.\n`;
          }
        });
      } else {
        summary += "Keine produzierenden Gebäude gefunden.";
      }

      alert(summary);
      loadResources();
      if (document.getElementById('province-view').style.display === 'flex' && window.currentView === 'province') {
        loadProvinceLager();
      }
    }
  } catch (error) {
    console.error('Fehler beim Rundenabschluss', error);
    alert('Verbindung zum Server fehlgeschlagen');
  }
}

// ── Exports ──────────────────────────────────────────────────
if (typeof window !== 'undefined') {
  window.loadResources       = loadResources;
  window.switchView          = switchView;
  window.nextTurn            = nextTurn;
  window.showProvinceSubView = showProvinceSubView;
  window.loadProvinceLager   = loadProvinceLager;
  window.resolveProvinzId    = resolveProvinzId;
}
